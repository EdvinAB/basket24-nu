'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { getLeagueInfo } from '@/lib/leagueFlags';

interface LeagueMenuItem {
  id: string;
  name: string;
  url: string;
}

const LEAGUE_ITEMS: LeagueMenuItem[] = [
  { id: 'nba', name: 'NBA', url: '/nba' },
  { id: 'euroleague', name: 'EuroLeague', url: '/euroleague' },
  { id: 'sbl', name: 'Svenska Basketligan', url: '/sbl' },
  { id: '117', name: 'ACB (Spanien)', url: '/acb' },
  { id: '104', name: 'Turkish BSL', url: '/turkish-bsl' },
  { id: '198', name: 'ABA Liga', url: '/aba-liga' },
  { id: '40', name: 'BBL (Tyskland)', url: '/bbl' },
  { id: '136', name: 'Greek Cup', url: '/greek-cup' },
  { id: '52', name: 'Lega A (Italien)', url: '/lega-a' },
  { id: '60', name: 'LKL (Litauen)', url: '/lkl' },
  { id: '85', name: 'KLS (Serbien)', url: '/kls' },
  { id: '86', name: 'Serbian Super League', url: '/serbian-super-league' },
];

interface LeagueMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function LeagueMenu({ isOpen, onClose }: LeagueMenuProps) {
  // Prevent body scroll when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  return (
    <>
      {/* Dark overlay */}
      <div
        className={`
          fixed inset-0 bg-black transition-opacity duration-300 z-[100]
          ${isOpen ? 'opacity-50' : 'opacity-0 pointer-events-none'}
        `}
        onClick={onClose}
      />

      {/* Slide-in menu from right */}
      <div
        className={`
          fixed top-0 right-0 h-full bg-white shadow-2xl z-[110]
          w-[90%] sm:w-[400px]
          transform transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : 'translate-x-full'}
        `}
      >
        {/* Header */}
        <div className="bg-dark text-white px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold">LIGOR</h2>
          {/* Close button */}
          <button
            onClick={onClose}
            className="text-white hover:text-primary transition-colors p-2"
            aria-label="Stäng meny"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M6 18L18 6M6 6l12 12"
              />
            </svg>
          </button>
        </div>

        {/* League list */}
        <div className="overflow-y-auto h-[calc(100%-64px)]">
          {LEAGUE_ITEMS.map((league) => {
            const leagueInfo = getLeagueInfo(league.id);
            
            return (
              <Link
                key={league.id}
                href={league.url}
                onClick={onClose}
                className="
                  flex items-center gap-4 px-6 py-4
                  border-b border-gray-200
                  hover:bg-gray-50 transition-colors
                "
              >
                {/* Flagga */}
                <div className="w-8 h-8 relative rounded overflow-hidden flex-shrink-0">
                  <Image
                    src={leagueInfo.flag}
                    alt={`${leagueInfo.name} flag`}
                    fill
                    className="object-cover"
                  />
                </div>

                {/* Logotyp */}
                <div className="w-10 h-10 relative flex-shrink-0">
                  <Image
                    src={leagueInfo.logo}
                    alt={`${leagueInfo.name} logo`}
                    fill
                    className="object-contain"
                  />
                </div>

                {/* Liga-namn */}
                <span className="text-dark font-semibold flex-1">
                  {league.name}
                </span>

                {/* Chevron */}
                <svg
                  className="w-5 h-5 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </Link>
            );
          })}
        </div>
      </div>
    </>
  );
}
